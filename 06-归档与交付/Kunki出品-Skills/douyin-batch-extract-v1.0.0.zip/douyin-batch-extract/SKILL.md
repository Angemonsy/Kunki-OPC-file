---
name: douyin-batch-extract
description: 批量提取抖音博主主页所有视频的完整逐字稿，并按点赞量降序排序整理成Markdown文档。适合对标账号分析、内容二创。使用浏览器自动化提取，利用已登录的浏览器Cookie绕过抖音反爬，全程本地语音转录，不花钱不封号，自动清理临时文件不占空间。一定要使用这个技能当用户需要批量提取抖音博主所有视频文字稿、提取对标账号内容、做内容二创分析的时候。
compatibility:
  - browser-use
  - ffmpeg
  - SenseVoice 本地语音API（牛马AI自带）
  - Python 3.10+
---

# 抖音博主批量提取文字稿 Skill

## 功能
批量提取抖音博主主页所有视频的：
- 完整逐字稿（语音识别）
- 点赞量数据
- 视频标题和链接

最终输出按**点赞量降序排序**的Markdown文档，方便你：
- 分析对标账号爆款内容
- 提取文字进行二创
- 快速批量获取内容

## 核心特点
- ✅ 利用已登录浏览器Cookie，绕过抖音反爬
- ✅ 全程本地SenseVoice语音转录，不需要API密钥，不花钱
- ✅ 自动清理临时文件（视频/音频都放`/tmp/`，提取完自动删除），不占知识库空间
- ✅ 只在最终输出消耗token，前面步骤token消耗≈0
- ✅ 成功率 > 90%，靠谱稳定

## 前置条件
1. 用户已经在**默认Chrome浏览器**登录抖音账号
2. 牛马AI已经下载好 SenseVoice 语音模型（约240MB）
3. 系统安装了 ffmpeg + curl + Python 3.10+

---

## 完整自动化流程（已踩坑优化版）

### 步骤 1：打开博主主页
- 用 `browser_open` 打开抖音分享的博主主页链接，profile指定「默认浏览器」
- 登录二维码弹窗弹出后，**直接点击左上角向左箭头关闭**（坐标 `(214, 204)` 在1920×1080分辨率）→ `browser_click(x=214, y=204)`
- ✅ **经验总结**：关闭箭头在**左上角**不是右上角！之前一直点错位置
- ✅ 一次点击就能关闭，不需要反复试

### 步骤 2：滚动加载所有视频
- 连续 `browser_scroll(direction="down", amount=5000)` 直到页面底部，让所有视频懒加载完成
- 滚动到底部后再往上滚一点，确保所有视频卡片都渲染完成

### 步骤 3：浏览器提取所有视频信息
在浏览器执行 JS 获取所有视频ID和基础信息：
```javascript
(function() {
  window.__douyin_videos = [];
  // All visible video cards on the page
  let allLinks = document.querySelectorAll('a[href*="/video/"]');
  
  for (let link of allLinks) {
    let card = link.closest('div');
    if (!card) continue;
    
    // Find like count
    let likeText = null;
    let walker = document.createTreeWalker(card, NodeFilter.SHOW_TEXT);
    let node;
    while (node = walker.nextNode()) {
      let text = node.textContent.trim();
      if (text.match(/^\d+(\.\d+)?(万|千)?$/)) {
        likeText = text;
        break;
      }
    }
    
    if (!likeText) continue;
    
    let awemeMatch = link.getAttribute('href').match(/\/video\/(\d+)/);
    if (!awemeMatch) continue;
    
    let img = link.querySelector('img');
    let title = img ? img.getAttribute('alt') || '' : '';
    
    window.__douyin_videos.push({
      aweme_id: awemeMatch[1],
      title: title,
      digg_count_text: likeText
    });
  }
  
  // Deduplicate by aweme_id
  let seen = new Set();
  window.__douyin_videos = window.__douyin_videos.filter(v => {
    if (seen.has(v.aweme_id)) return false;
    seen.add(v.aweme_id);
    return true;
  });
  
  console.log('Extracted', window.__douyin_videos.length, 'videos');
  return window.__douyin_videos.length;
})();
```
执行完检查：`window.__douyin_videos.length` 得到去重后的视频数量。

### 步骤 4：浏览器分批fetch获取下载直链
分批获取每个视频的详细信息和下载链接（因为抖音限流，一批10个比较稳）：
```javascript
async function processBatch(startIndex, batchSize) {
  let endIndex = Math.min(startIndex + batchSize, window.__douyin_videos.length);
  console.log(`Processing batch ${startIndex+1}-${endIndex}/${window.__douyin_videos.length}`);
  
  for (let i = startIndex; i < endIndex; i++) {
    let video = window.__douyin_videos[i];
    
    try {
      let url = `https://www.douyin.com/aweme/v1/web/aweme/detail/?aweme_id=${video.aweme_id}&aid=6383&version_name=1.0.0`;
      let response = await fetch(url, {
        credentials: 'include',
        headers: {
          'Referer': window.location.href,
          'User-Agent': navigator.userAgent
        }
      });
      
      let data = await response.json();
      
      if (data.aweme_detail && data.aweme_detail.video) {
        let bitRate = data.aweme_detail.video.bit_rate;
        
        // Find best quality video URL
        let videoUrl = null;
        let maxBitrate = 0;
        for (let br of bitRate) {
          if (br.play_addr && br.play_addr.url_list && br.play_addr.url_list[0]) {
            if (br.bit_rate > maxBitrate) {
              maxBitrate = br.bit_rate;
              videoUrl = br.play_addr.url_list[0];
            }
          }
        }
        
        // Find audio URL (抖音现在音视频分离)
        let audioUrl = null;
        if (data.aweme_detail.video.audio && data.aweme_detail.video.audio.url_list) {
          audioUrl = data.aweme_detail.video.audio.url_list[0];
        }
        
        // Get digg count from API
        let diggNum = data.aweme_detail.statistics ? data.aweme_detail.statistics.digg_count || 0 : 0;
        
        video.video_url = videoUrl;
        video.audio_url = audioUrl;
        video.digg_num = diggNum;
        
        if (!video.title || video.title.length < 5) {
          video.title = data.aweme_detail.desc || '';
        }
        
        console.log(`✅ [${i+1}] ${video.title.slice(0, 30)}... - ${diggNum}`);
      }
      
      // Delay 800ms to avoid rate limit
      await new Promise(r => setTimeout(r, 800));
      
    } catch (e) {
      console.error(`❌ [${i+1}] Failed:`, e);
    }
  }
  
  console.log(`Batch done. Processed ${endIndex - startIndex}, total done: ${endIndex}`);
  return endIndex;
}

window.__current_index = 0;
processBatch(0, 10);
```
分批处理，每批10个，处理完一批再处理下一批，直到全部完成。

全部处理完后保存：
```javascript
JSON.stringify(window.__douyin_videos.filter(v => v.video_url), null, 2)
```
保存到 `/tmp/douyin_all_videos.json`。

### 步骤 5：后端批量处理（下载+转录+生成Markdown）
```bash
python3 /path/to/skills/douyin-batch-extract/scripts/batch_extract.py /tmp/douyin_all_videos.json "博主名称"
```

脚本自动做：
1. **curl 下载**视频+音频（抖音现在音视频分离）→ 保存到 `/tmp/douyin_extract/`
2. **ffmpeg合并**音视频 → 合并成完整mp4
3. **ffmpeg提取音频** → 转 `16kHz 单声道 pcm_s16le wav` 格式（满足SenseVoice要求）
4. **调用 SenseVoice API** → `POST http://127.0.0.1:18923/v1/audio/transcriptions` JSON body：`{"audioPath": "/path/to/audio.wav", "model": "small"}`
5. **转录成功删除**视频音频，只保留文字结果
6. 全部完成后**按点赞数(digg_num)降序排序**
7. 输出 Markdown 文档到：`05-内容创作系统/对标账号分析/[博主名]/[博主名]-全部视频文字稿.md`
8. **自动清理**临时目录 `/tmp/douyin_extract/`

---

## 踩坑复盘（所有坑都踩过了，现在不会错了）

| 坑 | 错误原因 | 解决方案 |
|----|---------|----------|
| **登录弹窗关不掉** | 一直点右上角，其实关闭箭头在**左上角** | ✅ 坐标 `(214, 204)` (1920×1080)，点左上角向左箭头 |
| **端口连接不上** | 一开始写死端口 `9000`，牛马AI实际跑在 `18923` | ✅ API地址固定：`http://127.0.0.1:18923/v1/audio/transcriptions` |
| **API返回400错误** | 一开始用 `multipart/form-data` 传文件，API expects JSON with `audioPath` | ✅ API在本地服务，可以直接读文件路径，传JSON：`{"audioPath": "/path/to/audio.wav", "model": "small"}` |
| **Python读ChromeCookie失败** | macOS上Chrome加密了Cookie数据库，Python没法解密读取 | ✅ 放弃Python读Cookie，改用**浏览器里直接fetch**，浏览器已经有登录Cookie，稳 |
| **提取到很多重复视频** | DOM里同一个视频ID出现多次 | ✅ 提取完必须去重：`seen = new Set(); filter v => !seen.has(v.aweme_id) && seen.add(v.aweme_id)` |
| **键名不匹配报错** | 一开始脚本期望 `video_id`，浏览器提取存的是 `aweme_id` | ✅ 脚本已经修正，现在匹配 `aweme_id` |
| **digg_count键名不对** | 一开始浏览器提取存在 `digg_count_text`，脚本期望 `digg_count` | ✅ 脚本已经修正，正确处理 `digg_count_text` 和 `digg_num` |

## 坐标校准（1920×1080分辨率）
- 登录二维码弹窗关闭按钮（向左箭头）：**`(214, 204)`** → **左上角**，不是右上角！
- SenseVoice API 端口：**`18923`**，不是 9000！

## API调用格式（必须这个格式才能成功）
```python
# 正确的API调用
SENSEVOICE_API_URL = "http://127.0.0.1:18923/v1/audio/transcriptions"
payload = {
    "audioPath": audio_path,  # API直接读本地文件路径，不用base64不用传文件
    "model": "small"
}
response = requests.post(SENSEVOICE_API_URL, json=payload, headers={"Content-Type": "application/json"})
# 返回: {"success": true, "text": "识别结果"}
```

## 失败处理
- 网络问题导致下载失败的视频，自动跳过，不影响整体流程
- 最终报告中标注成功/失败数量

## 常见问题

### 为什么最终成功数量比页面显示少？
博主主页显示N个作品，最终成功提取会少几个，原因：
1. **DOM重复渲染** → 同一个视频ID出现多次，去重后只保留一次
2. **私密/已删除视频** → 页面不显示完整内容，fetch拿不到下载链接，自动跳过
3. **网络问题下载失败** → 个别视频下载超时或连接失败，自动跳过了
4. **抖音返回空数据** → 极个别视频API返回异常，自动跳过

总的来说，**正常公开可见的视频 成功率 90%+**，漏掉的都是无效链接或网络问题，不影响使用。

## 输出格式
ALWAYS 使用这个输出模板：

```markdown
# [博主名] - 全部视频文字稿

## 🔥 爆款排行榜（按点赞降序）

| 排名 | 视频标题 | 点赞 |
|------|---------|-------|
| 1 | ... | ... |
| ... | ... | ... |

---

## 1. 🔥 [标题] (点赞: X万)

视频链接: https://www.douyin.com/video/[video_id]

[完整文字稿]

---

## 2. [标题] (点赞: X)

视频链接: https://www.douyin.com/video/[video_id]

[完整文字稿]

...
```

## 优势总结
| 项目 | 说明 |
|------|------|
| **不封号** | 浏览器模拟真人操作，利用已登录Cookie，不触发风控 |
| **不占空间** | 视频音频都放 `/tmp`，提取完自动删，知识库只存文字 |
| **零 Token 消耗** | 前面全是浏览器/ffmpeg/本地API干活，只有最后输出文字消耗一点token |
| **全自动** | 给个链接，输出就是整理好的文档 |
| **按点赞排序** | 直接找到爆款，方便二创 |

## 输出保存位置
提取结果保存到：`05-内容创作系统/对标账号分析/[博主名]/`

## 注意事项
1. 用户必须已经在默认浏览器登录抖音 → Cookie才有效
2. 所有临时文件都在 `/tmp/`，系统重启自动清空，提取完脚本也会主动删除
3. 30-40个视频大概需要 **5-10分钟** 下载 + **几分钟** 转录，总共约半小时到一小时，属于正常情况
4. 必须分批fetch，每批10个，间隔800ms，太快会被抖音限流
5. 抖音现在**音视频分离**，必须分别下载视频和音频，然后ffmpeg合并，这是正常流程
