#!/usr/bin/env python3
"""
抖音批量提取文字稿
- 读取浏览器提取的视频数据JSON
- 批量下载视频
- ffmpeg提取音频
- 调用本地SenseVoice API转录
- 自动清理临时文件
"""

import json
import os
import subprocess
import requests
from typing import List, Dict

SENSEVOICE_API_URL = "http://127.0.0.1:18923/v1/audio/transcriptions"
TEMP_DIR = "/tmp/douyin_extract"

def ensure_temp_dir():
    """创建临时目录"""
    if not os.path.exists(TEMP_DIR):
        os.makedirs(TEMP_DIR)

def download_video_by_ytdlp(video_id: str) -> str:
    """用yt-dlp配合cookie下载完整视频（自动合并音视频）"""
    output = f"{TEMP_DIR}/{video_id}.mp4"
    cmd = [
        "yt-dlp", "-f", "bestvideo+bestaudio/best", "--merge-output-format", "mp4",
        "--cookies", "/tmp/cookies.txt",
        "-o", output,
        f"https://www.douyin.com/video/{video_id}",
        "--no-warnings"
    ]
    result = subprocess.run(cmd, capture_output=True, text=True);
    if result.returncode != 0:
        print(f"❌ yt-dlp 下载失败 {video_id}: {result.stderr}");
        return None;
    if not os.path.exists(output) or os.path.getsize(output) < 100000:
        print(f"❌ 下载文件太小 {video_id}");
        if os.path.exists(output):
            os.remove(output);
        return None;
    return output;

def download_video(bit_rates: list, video_id: str) -> str:
    """抖音现在音视频分离，找到视频+audio分别下载然后合并"""
    # 找最高质量视频
    video_bitrate = None
    audio_bitrate = None

    for br in bit_rates:
        if br.get("media_type") == "video":
            if video_bitrate is None or br.get("bitrate", 0) > video_bitrate.get("bitrate", 0):
                video_bitrate = br
        elif br.get("media_type") == "audio":
            if audio_bitrate is None or br.get("bitrate", 0) > audio_bitrate.get("bitrate", 0):
                audio_bitrate = br

    if not video_bitrate or not audio_bitrate:
        print(f"❌ 找不到视频或音频 {video_id}")
        return None

    video_url = video_bitrate["play_addr"]["url_list"][0]
    audio_url = audio_bitrate["play_addr"]["url_list"][0]

    video_path = download_media(video_url, video_id, "video")
    if not video_path:
        return None

    audio_path = download_media(audio_url, video_id, "audio")
    if not audio_path:
        if os.path.exists(video_path):
            os.remove(video_path)
        return None

    # 合并音视频
    output_path = f"{TEMP_DIR}/{video_id}_merged.mp4"
    cmd = [
        "ffmpeg", "-y",
        "-i", video_path,
        "-i", audio_path,
        "-c:v", "copy",
        "-c:a", "aac",
        output_path
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"❌ 合并音视频失败 {video_id}: {result.stderr}")
        return None

    # 清理分开的文件
    os.remove(video_path)
    os.remove(audio_path)

    return output_path

def extract_audio(video_path: str, video_id: str) -> str:
    """ffmpeg提取音频"""
    audio_path = f"{TEMP_DIR}/{video_id}.wav"
    # Use -vn to disable video, force extract audio -a
    cmd = [
        "ffmpeg", "-y", "-i", video_path,
        "-vn", "-acodec", "pcm_s16le",
        "-ar", "16000", "-ac", "1",
        audio_path
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        # Try alternative method: specify all audio streams
        cmd2 = [
            "ffmpeg", "-y", "-i", video_path,
            "-vn", "-acodec", "pcm_s16le",
            "-ar", "16000", "-ac", "1",
            "-map", "0:a",
            audio_path
        ]
        result2 = subprocess.run(cmd2, capture_output=True, text=True)
        if result2.returncode != 0:
            print(f"❌ 提取音频失败 {video_id}: {result.stderr}")
            return None
    return audio_path

def transcribe_audio(audio_path: str) -> str:
    """调用SenseVoice API转录"""
    headers = {
        "Referer": "http://127.0.0.1:18923",
        "Content-Type": "application/json"
    }
    payload = {
        "audioPath": audio_path,
        "model": "small"
    }
    try:
        response = requests.post(
            SENSEVOICE_API_URL,
            json=payload,
            headers=headers,
            timeout=300
        )
        response.raise_for_status()
        result = response.json()
        # API returns {"success": true, "text": "..."}
        if result.get("success"):
            return result.get("text", "")
        else:
            print(f"❌ 转录失败: {result.get('error', 'unknown error')}")
            return None
    except Exception as e:
        print(f"❌ 转录失败: {e}")
        return None

def clean_up(video_path: str, audio_path: str):
    """清理临时文件"""
    for path in [video_path, audio_path]:
        if path and os.path.exists(path):
            os.remove(path)

def download_media(url: str, video_id: str, media_type: str) -> str:
    """下载视频/音频文件"""
    output = f"{TEMP_DIR}/{video_id}_{media_type}.{'mp4' if media_type == 'video' else 'aac'}"
    cmd = [
        "curl", "-L", "-o", output,
        "-H", f"Referer: https://www.douyin.com/video/{video_id}",
        "-H", f"User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        url
    ]
    result = subprocess.run(cmd, capture_output=True, text=True);
    if result.returncode != 0:
        print(f"❌ 下载{media_type}失败 {video_id}: {result.stderr}");
        return None;
    if not os.path.exists(output) or os.path.getsize(output) < 10000:
        print(f"❌ {media_type}文件太小 {video_id}");
        if os.path.exists(output):
            os.remove(output);
        return None;
    return output;

def process_videos(json_path: str, blogger_name: str):
    """处理所有视频"""
    ensure_temp_dir()

    # 读取数据
    with open(json_path, "r", encoding="utf-8") as f:
        videos = json.load(f)

    print(f"📋 开始处理 {len(videos)} 个视频...")

    results = []
    success_count = 0

    # 输出路径
    output_path = f"/Users/kunki/ObsidianVaults/领航知识库/05-内容创作系统/对标账号分析/{blogger_name}/{blogger_name}-全部视频文字稿.md"

    # 确保目录存在
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    for i, video in enumerate(videos, 1):
        video_id = video["aweme_id"]
        title = video["title"]
        digg_count = video.get("digg_count_text", str(video.get("digg_num", "")))
        digg_num = video.get("digg_num", 0)
        video_url = video["video_url"]
        audio_url = video.get("audio_url")

        print(f"\n[{i}/{len(videos)}] 处理: {title[:50]}...")

        # 下载视频和音频（抖音现在音视频分离）
        video_path = download_media(video_url, video_id, "video")
        if not video_path:
            continue

        # 如果有单独音频，下载合并
        if audio_url:
            audio_path_download = download_media(audio_url, video_id, "audio")
            if not audio_path_download:
                clean_up(video_path, None)
                continue

            # 合并音视频
            merged_path = f"{TEMP_DIR}/{video_id}_merged.mp4"
            cmd = [
                "ffmpeg", "-y",
                "-i", video_path,
                "-i", audio_path_download,
                "-c:v", "copy",
                "-c:a", "aac",
                merged_path
            ]
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode != 0:
                print(f"❌ 合并音视频失败 {video_id}: {result.stderr}")
                clean_up(video_path, audio_path_download)
                continue

            # 清理分开的文件
            clean_up(video_path, audio_path_download)
            video_path = merged_path

        # 提取音频
        audio_path = extract_audio(video_path, video_id)
        if not audio_path:
            clean_up(video_path, None)
            continue

        # 转录
        text = transcribe_audio(audio_path)
        if text is None:
            clean_up(video_path, audio_path)
            continue

        # 添加完整分享链接
        video["share_url"] = f"https://www.douyin.com/video/{video_id}"

        # 转换点赞数为数字
        try:
            if "万" in digg_count:
                digg_num = float(digg_count.replace("万", "")) * 10000
            else:
                digg_num = int(digg_count.replace(",", "").replace("赞", ""))
        except:
            digg_num = 0
        video["digg_num"] = digg_num

        # 保存结果
        video["text"] = text
        results.append(video)
        success_count += 1
        print(f"✅ 成功: {digg_count} 赞 - {len(text)} 字")

        # 清理
        clean_up(video_path, audio_path)
    
    # 按点赞降序排序
    results.sort(key=lambda x: x["digg_num"], reverse=True)

    # 保存结果JSON
    result_json = output_path.replace(".md", ".json")
    with open(result_json, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    # 生成Markdown
    generate_markdown(results, output_path)

    print(f"\n🎉 处理完成！成功: {success_count}/{len(videos)}")
    print(f"📄 结果保存到: {output_path}")

    # 清理临时目录
    try:
        subprocess.run(["rm", "-rf", TEMP_DIR], check=True)
    except:
        pass

def generate_markdown(results: List[Dict], output_path: str):
    """生成Markdown文档"""
    with open(output_path, "w", encoding="utf-8") as f:
        # 标题
        blogger_name = os.path.basename(output_path).replace("-全部视频文字稿.md", "")
        f.write(f"# {blogger_name} - 全部视频文字稿\n\n")
        
        # 排行榜
        f.write("## 🔥 爆款排行榜（按点赞降序）\n\n")
        f.write("| 排名 | 视频标题 | 点赞 |\n")
        f.write("|------|---------|-------|\n")
        for i, video in enumerate(results, 1):
            title = video["title"]
            digg = format_digg(video["digg_num"])
            f.write(f"| {i} | **{title}** | {digg} |\n")
        
        f.write("\n---\n\n")
        
        # 逐个文字稿
        for i, video in enumerate(results, 1):
            title = video["title"]
            digg = format_digg(video["digg_num"])
            text = video["text"]
            url = video["share_url"]
            
            # 标题行
            if i == 1:
                f.write(f"## {i}. 🔥 {title} (点赞: {digg})\n\n")
            else:
                f.write(f"## {i}. {title} (点赞: {digg})\n\n")
            
            f.write(f"视频链接: {url}\n\n")
            f.write(text + "\n\n")
            f.write("---\n\n")

def format_digg(digg_num: int) -> str:
    """格式化点赞数"""
    if digg_num >= 10000:
        return f"{digg_num / 10000:.1f}万"
    return str(digg_num)

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("用法: python batch_extract.py <输入JSON> <博主名称>")
        sys.exit(1)

    process_videos(sys.argv[1], sys.argv[2])
