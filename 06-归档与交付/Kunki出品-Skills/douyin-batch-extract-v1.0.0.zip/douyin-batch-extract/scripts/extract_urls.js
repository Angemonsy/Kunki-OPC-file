/**
 * 抖音博主主页提取所有视频直链
 * 在浏览器中执行，提取所有视频ID和下载地址
 * 输出: JSON数组保存到window.__DOUYIN_VIDEOS
 */

async function extractAllVideos() {
    console.log('🔍 开始提取视频数据...');
    
    // 滚动到底部加载所有视频
    await scrollToBottom();
    
    // 提取视频卡片
    const videoCards = document.querySelectorAll('[data-e2e="user-post-item"]');
    console.log(`找到 ${videoCards.length} 个视频卡片`);
    
    const videos = [];
    
    for (let card of videoCards) {
        try {
            // 提取视频ID
            const link = card.querySelector('a');
            if (!link) continue;
            
            const href = link.getAttribute('href');
            const videoIdMatch = href.match(/\/video\/(\d+)/);
            if (!videoIdMatch) continue;
            
            const videoId = videoIdMatch[1];
            
            // 提取标题
            const titleEl = card.querySelector('[data-e2e="video-desc"]');
            const title = titleEl ? titleEl.textContent.trim() : 'untitled';
            
            // 提取点赞数
            const diggEl = card.querySelector('[data-e2e="like-count"]');
            let diggCount = 0;
            if (diggEl) {
                const text = diggEl.textContent.trim();
                diggCount = parseCount(text);
            }
            
            // 提取分享链接
            const shareUrl = window.location.origin + href;
            
            videos.push({
                video_id: videoId,
                title: title,
                digg_count: diggCount,
                share_url: shareUrl
            });
            
        } catch (e) {
            console.error('提取单个视频失败', e);
            continue;
        }
    }
    
    console.log(`成功提取 ${videos.length} 个视频基础信息`);
    
    // 逐个提取播放地址
    for (let i = 0 i < videos.length; i++) {
        const video = videos[i];
        console.log(`提取直链 ${i+1}/${videos.length}: ${video.title}`);
        
        try {
            const playAddr = await fetchVideoPlayAddr(video.video_id);
            if (playAddr) {
                video.play_addr = playAddr;
            } else {
                console.warn(`提取直链失败: ${video.video_id}`);
            }
        } catch (e) {
            console.error(`提取直链出错 ${video.video_id}`, e);
        }
        
        // 稍微延迟一下，避免请求太快
        await sleep(200);
    }
    
    // 过滤掉没有play_addr的
    const validVideos = videos.filter(v => v.play_addr);
    console.log(`最终有效视频: ${validVideos.length}/${videos.length}`);
    
    window.__DOUYIN_VIDEOS = validVideos;
    return validVideos;
}

async function scrollToBottom() {
    /**滚动到底部加载所有视频 */
    return new Promise(resolve => {
        let lastHeight = document.body.scrollHeight;
        let attempts = 0;
        const timer = setInterval(() => {
            window.scrollTo(0, document.body.scrollHeight);
            const newHeight = document.body.scrollHeight;
            if (newHeight === lastHeight || attempts > 20) {
                clearInterval(timer);
                resolve();
            }
            lastHeight = newHeight;
            attempts++;
        }, 1000);
    });
}

function parseCount(text) {
    /**解析点赞数字符串转数字 */
    if (!text) return 0;
    text = text.trim().toLowerCase();
    if (text.includes('w') || text.includes('万')) {
        const num = parseFloat(text) * 10000;
        return Math.round(num);
    }
    return parseInt(text.replace(/[^\d]/g, '')) || 0;
}

async function fetchVideoPlayAddr(awemeId) {
    /**调用抖音API获取视频播放地址 */
    const url = `https://www.douyin.com/aweme/v1/web/aweme/detail/?aweme_id=${awemeId}`;
    
    try {
        const response = await fetch(url, {
            method: 'GET',
            credentials: 'include',
            headers: {
                'Accept': 'application/json',
                'Referer': window.location.href
            }
        });
        
        const data = await response.json();
        
        if (data && data.aweme_detail && data.aweme_detail.video) {
            const playAddr = data.aweme_detail.video.play_addr;
            if (playAddr && playAddr.url_list && playAddr.url_list.length > 0) {
                // 拿第一个可用地址
                return playAddr.url_list[0];
            }
        }
        
        return null;
    } catch (e) {
        console.error('API请求失败', e);
        return null;
    }
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// 执行提取
extractAllVideos();
