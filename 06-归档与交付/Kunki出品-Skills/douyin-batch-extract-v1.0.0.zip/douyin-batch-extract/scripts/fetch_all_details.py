#!/usr/bin/env python3
"""
提取所有视频详细信息
从video_ids.json读取ID，逐个获取详情，保存到videos.json
"""

import json
import requests
import sys
import time
import os
from shutil import copyfile
import sqlite3

# 从Chrome读取cookie
def get_chrome_cookies(domain):
    """Get cookies from Chrome for a domain"""
    cookie_path = os.path.expanduser('~/Library/Application Support/Google/Chrome/Default/Cookies')
    if not os.path.exists(cookie_path):
        print(f"❌ Chrome cookie file not found at {cookie_path}")
        return None

    # Copy to temp because Chrome locks it
    temp_cookie = '/tmp/chrome_cookies'
    copyfile(cookie_path, temp_cookie)

    conn = sqlite3.connect(temp_cookie)
    cursor = conn.cursor()

    query = """
    SELECT host_key, name, value, path, expires_utc, is_secure
    FROM cookies
    WHERE host_key LIKE '%{}%'
    """.format(domain)

    cursor.execute(query)
    cookies = {}
    for row in cursor.fetchall():
        host_key, name, value, path, expires_utc, is_secure = row
        cookies[name] = value

    conn.close()
    os.remove(temp_cookie)
    return cookies

def main():
    if len(sys.argv) != 2:
        print("Usage: python fetch_all_details.py <video_ids.json>")
        sys.exit(1)

    with open(sys.argv[1], 'r') as f:
        video_ids = json.load(f)

    print(f"📋 准备提取 {len(video_ids)} 个视频的详细信息...")

    # Get cookies from Chrome
    cookies = get_chrome_cookies('douyin.com')
    if not cookies:
        print("❌ 未能获取抖音Cookie，请确保Chrome已登录抖音")
        sys.exit(1)

    cookie_str = '; '.join([f'{k}={v}' for k, v in cookies.items()])

    headers = {
        'Referer': 'https://www.douyin.com/',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Cookie': cookie_str
    }

    videos = []

    for i, video_id in enumerate(video_ids, 1):
        print(f"\n[{i}/{len(video_ids)}] 提取视频 {video_id}...")

        url = f"https://www.douyin.com/aweme/v1/web/aweme/detail/?aweme_id={video_id}&aid=6383&version_name=1.0.0"

        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            data = response.json()

            if data.get('aweme_detail') and data['aweme_detail'].get('video'):
                aweme = data['aweme_detail']
                video_data = aweme['video']

                # Find best quality video
                bit_rate = video_data['bit_rate']
                video_url = None
                max_bitrate = 0
                for br in bit_rate:
                    if br.get('play_addr') and br['play_addr'].get('url_list') and br['play_addr']['url_list'][0]:
                        if br['bit_rate'] > max_bitrate:
                            max_bitrate = br['bit_rate']
                            video_url = br['play_addr']['url_list'][0]

                # Find audio URL
                audio_url = None
                if video_data.get('audio') and video_data['audio'].get('url_list'):
                    audio_url = video_data['audio']['url_list'][0]

                # Get digg count
                digg_num = aweme.get('statistics', {}).get('digg_count', 0)
                digg_count = str(digg_num)
                # Convert to friendly format if >= 10000
                if digg_num >= 10000:
                    digg_count = f"{digg_num / 10000:.1f}万"

                # Get title desc
                title = aweme.get('desc', '')

                videos.append({
                    'aweme_id': video_id,
                    'title': title,
                    'digg_count': digg_count,
                    'digg_num': digg_num,
                    'video_url': video_url,
                    'audio_url': audio_url
                })

                print(f"✅ 成功: {title[:50]}... ({digg_count})")
            else:
                print(f"❌ 没有找到视频数据")

            # Delay to avoid rate limit
            time.sleep(1)

        except Exception as e:
            print(f"❌ 请求失败: {e}")
            continue

    # Save result
    output_file = '/tmp/douyin_all_videos.json'
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(videos, f, ensure_ascii=False, indent=2)

    print(f"\n🎉 提取完成！成功: {len(videos)}/{len(video_ids)}")
    print(f"📄 结果保存到: {output_file}")

if __name__ == '__main__':
    main()