#!/bin/bash
# Social Content Fetcher - 自动安装脚本
# Install script for social-content-fetcher Claude Code / 牛马AI Skill

set -e

echo "======================================"
echo "  Social Content Fetcher 安装程序"
echo "======================================"
echo ""

if [ ! -d "social-content-fetcher" ]; then
  echo "❌ 错误：请在解压后的安装包根目录运行此脚本"
  exit 1
fi

install_to() {
  local target_dir="$1"
  local label="$2"
  mkdir -p "$target_dir"
  if [ -d "$target_dir/social-content-fetcher" ]; then
    echo "⚠️  [$label] 检测到已存在旧版本，备份为 .backup"
    rm -rf "$target_dir/social-content-fetcher.backup"
    mv "$target_dir/social-content-fetcher" "$target_dir/social-content-fetcher.backup"
  fi
  cp -R social-content-fetcher "$target_dir/"
  chmod +x "$target_dir/social-content-fetcher/scripts/workflow.sh"
  echo "✅ [$label] 安装完成: $target_dir/social-content-fetcher/"
}

echo "▶️  安装到 Claude Code 技能目录..."
install_to ~/.claude/skills "Claude Code"
echo ""
echo "▶️  安装到 牛马AI 技能目录..."
install_to ~/.newmax/skills "牛马AI"

echo ""
echo "======================================"
echo "  ✅ 全部安装完成！"
echo "======================================"
echo ""
echo "📋 安装位置："
echo "   Claude Code: ~/.claude/skills/social-content-fetcher/"
echo "   牛马AI:      ~/.newmax/skills/social-content-fetcher/"
echo ""
echo "🔧 下一步："
echo "   1. 重启 Claude Code / 牛马AI"
echo "   2. 测试使用: /social-content-fetcher <抖音或小红书链接>"
echo ""
