# Social Content Fetcher v1.0 — Kunki原创封装

> 一键把抖音/小红书视频链接转为：**互动数据 + 正文 + 完整逐字稿**  
> 专为内容创作者、爆款分析、对标研究设计，全自动省时间。

---

## 🎯 功能特点

| 功能 | 说明 |
|------|------|
| ✅ **一键抓取** | 丢链接进来，全自动跑完所有流程 |
| ✅ **数据完整** | 点赞、收藏、评论、转发、作者、发布时间一网打尽 |
| ✅ **正文提取** | 平台原文 + 话题标签完整提取 |
| ✅ **自动转写** | 本地 faster-whisper 转写逐字稿，隐私安全 |
| ✅ **空间优化** | 默认自动删除视频音频，只保留文字内容，节省磁盘 |
| ✅ **支持双平台** | 抖音 + 小红书，支持短链接直接处理 |

---

## 📋 前置依赖

安装本 Skill 之前，需要先安装：

1. **agent-reach** — 通常已经包含在 Claude Code 技能包中，如果没有请到 [Agent-Reach](https://github.com/Panniantong/agent-reach) 安装。

2. **mrcarlsama-social-transcriber** — 从官方GitHub安装：
```bash
# 克隆仓库
git clone https://github.com/MrCarlsama/mrcarlsama-social-transcriber-skill.git
cd mrcarlsama-social-transcriber-skill

# 安装 uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# 自动安装所有依赖
uv run --script skills/mrcarlsama-social-transcriber/scripts/bootstrap.py --ensure

# 安装到 Claude Code
mkdir -p ~/.claude/skills
cp -R skills/mrcarlsama-social-transcriber ~/.claude/skills/

# 重启 Claude Code 生效
```

---

## 🚀 一键安装 Social Content Fetcher

下载本安装包后，在解压后的目录执行：

```bash
./install.sh
```

脚本会自动把 Skill 复制到 `~/.claude/skills/social-content-fetcher/`。

### 手动安装

```bash
# 复制 Skill 目录
mkdir -p ~/.claude/skills
cp -R social-content-fetcher ~/.claude/skills/
```

安装完成后**重启 Claude Code** 即可使用。

---

## 💡 使用方法

### 基础用法（推荐）

在 Claude Code 中直接调用：

```
/social-content-fetcher <抖音或小红书链接>
```

**示例：**
```
# 小红书
/social-content-fetcher http://xhslink.com/o/9Be3xuaU13G

# 抖音
/social-content-fetcher https://v.douyin.com/iFjYwUy/
```

### 保留原视频文件

如果需要保留原视频和音频（默认会删除节省空间）：

```
/social-content-fetcher --keep-media <链接>
```

---

## 📊 输出示例

处理完成后，AI 会输出整合结果：

| 指标 | 数据 |
|------|------|
| **标题** | 自媒体账号是大学生社交的第二张名片 |
| **作者** | 我是林kunki |
| **发布时间** | 05-21 广东 |
| **点赞** | 5 |
| **收藏** | 3 |
| **评论** | 1 |

**平台正文：**
> 推荐大家都可以做一个自己的自媒体账号...

**视频逐字稿：**
```
我以前有一个误区
我觉得做自媒体账号一定要爆款
...
共勉
```

---

## 🔧 支持链接格式

### 小红书
- `https://www.xiaohongshu.com/discovery/item/...`
- `http://xhslink.com/...` (分享短链接)

### 抖音
- `https://www.douyin.com/video/...`
- `https://v.douyin.com/...` (分享短链接)

---

## 💾 空间占用说明

- 首次运行依赖会自动下载 faster-whisper 模型（约 1GB-2GB）
- 处理完默认删除原视频/音频，只保留文字，不占额外空间
- 如果开启 `--keep-media`，每个视频会占用几十MB空间

---

## 🎓 适用场景

1. **爆款拆解分析** — 看到好视频一键转文字，研究结构和文案
2. **对标博主研究** — 批量获取对标账号内容，总结方法论
3. **干货提取** — 提取口播干货，整理成自己的笔记
4. **内容二次创作** — 基于逐字稿改写，创作新内容
5. **知识沉淀** — 把有用视频保存为文字，存入知识库

---

## 📦 安装包内容

```
social-content-fetcher-v1.0.0.zip
├── install.sh                 # 一键安装脚本
├── README.md                 # 完整安装使用说明
└── social-content-fetcher/    # Skill 本体
    ├── SKILL.md              # Claude Code Skill 定义
    └── scripts/
        └── workflow.sh       # 组合工作流脚本
```

---

## 🎯 核心价值

做爆款拆解、对标分析还在**手动下载→转音频→上传转写**？太麻烦了！

**现在：丢一条链接进来，2分钟拿到「点赞+收藏+评论+正文+完整逐字稿」，全自动省出半小时。**

---

**出品**：Kunki  
**版本**：v1.0.0  
**更新日期**：2026-06-10  
**兼容**：Claude Code / macOS / Linux  

---

© 2026 Kunki. All rights reserved.
