#!/bin/bash
# IP自传挖掘师 - 自动安装脚本
# Install script for ip-autobiography-digger Claude Code / 牛马AI Skill

set -e

echo "======================================"
echo "   IP自传挖掘师 安装程序"
echo "======================================"
echo ""

if [ ! -d "ip-autobiography-digger" ]; then
  echo "❌ 错误：请在解压后的安装包根目录运行此脚本"
  exit 1
fi

install_to() {
  local target_dir="$1"
  local label="$2"
  mkdir -p "$target_dir"
  if [ -d "$target_dir/ip-autobiography-digger" ]; then
    echo "⚠️  [$label] 检测到已存在旧版本，备份为 .backup"
    rm -rf "$target_dir/ip-autobiography-digger.backup"
    mv "$target_dir/ip-autobiography-digger" "$target_dir/ip-autobiography-digger.backup"
  fi
  cp -R ip-autobiography-digger "$target_dir/"
  echo "✅ [$label] 安装完成: $target_dir/ip-autobiography-digger/"
}

echo "▶️  安装到 Claude Code 技能目录..."
install_to ~/.claude/skills "Claude Code"
echo ""
echo "▶️  安装到 牛马AI 技能目录..."
install_to ~/.newmax/skills "牛马AI"

echo ""
echo "======================================"
echo "  ✅ 全部安装完成！"
echo "======================================"
echo ""
echo "📋 安装位置："
echo "   Claude Code: ~/.claude/skills/ip-autobiography-digger/"
echo "   牛马AI:      ~/.newmax/skills/ip-autobiography-digger/"
echo ""
echo "🔧 下一步："
echo "   1. 重启 Claude Code / 牛马AI"
echo "   2. 开始使用: /ip-autobiography-digger"
echo ""
